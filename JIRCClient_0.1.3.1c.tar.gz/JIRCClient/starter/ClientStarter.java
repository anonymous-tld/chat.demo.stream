package starter;

public class ClientStarter {

	private ClientStarter() {
		Splash sp = Splash.getSplashScreen();
		sp.start();
	}

	public static void main(String[] args) {
		new ClientStarter();
	}

}
