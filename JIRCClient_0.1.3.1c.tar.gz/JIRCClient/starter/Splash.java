package starter;

import java.awt.BorderLayout;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import gui.ClientGUI;

public class Splash extends Thread {

	private static int splashCount = 0;

	private JFrame jf = new JFrame("JIRC - loading..");

	/**
	 * The Splash-Class has got a private constructor to make sure it's only
	 * called once!
	 */
	private Splash() {

	}

	/**
	 * 
	 * @return Splash (instance of Splash - if none exists so far)
	 */
	public static Splash getSplashScreen() {
		if (splashCount == 0) {
			splashCount = 1;
			return new Splash();
		} else {
			return null;
		}
	}

	/**
	 * this little method builds up a splash-screen using the logo.png file in
	 * /img
	 * 
	 */
	private void buildSplashScreen() {
		JLabel jl = new JLabel();
		jf.setLayout(new BorderLayout());
		Image logo = jf.getToolkit().getImage(
				getClass().getResource("/img/logo.png"));
		jl.setIcon(new ImageIcon(logo));
		jf.add(jl);
		jf.pack();
		jf.setResizable(false);
		jf.setLocationRelativeTo(null);
		jf.setVisible(true);
		jf.repaint();

	}

	@Override
	@SuppressWarnings("static-access")
	public void run() {
		try {
			buildSplashScreen();

			this.sleep(2000);

			ClientGUI cgui = new ClientGUI();
			cgui.setVisible(true);

			jf.setVisible(false);
		} catch (Exception e) {

		}
	}

}
