package messages;

import gui.comp.ListEntry;

import java.io.File;
import java.io.FileWriter;
import java.util.StringTokenizer;

import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;

import dialogs.FileAcceptDialog;

import userManagement.User;
import worker.MWorker;

public class ClientMessageHandler {

	static int count = 0;

	private MWorker mw;

	/**
	 * 
	 * @param mw
	 *            ... the MWorker the ClientMessageHandler needs for processing
	 *            data
	 */
	private ClientMessageHandler(MWorker mw) {
		this.mw = mw;
	}

	/**
	 * 
	 * @param mw
	 *            ... the MWorker the ClientMessageHandler needs for processing
	 *            data
	 * @return a ClientMessageHandler if none exists so far
	 */
	public static ClientMessageHandler getAClientMessageHandler(MWorker mw) {
		if (count == 0) {
			count++;
			return new ClientMessageHandler(mw);
		} else {
			return null;
		}
	}

	/**
	 * 
	 * @param msg
	 *            ... the Message to be handled
	 * @see Message
	 */
	public void handleMessage(Message msg) {
		User u = new User(msg.getSender(), "");
		if (u.getNic().equals("userlist")) {
			newUserList(msg.getText());
		} else if (msg.getFile() != null) {
			System.out.println("incoming file transfer!!... \n"
					+ "getting file: " + msg.getFile().getName() + " from: "
					+ msg.getSender());
			downloadFileFromMessage(msg);
		} else {
			System.out.println("message: " + msg.getSender() + " : "
					+ msg.getText());
			mw.accessGUI().incomingMessage(msg.getSender(), msg.getText());
		}
	}

	/**
	 * This little method takes a object of type message, and tries to download
	 * the file of it .. (FileChooser etc. included)
	 * 
	 * @param msg
	 *            ... the Message, from which the file will be downloaded
	 * @see Message
	 */
	private void downloadFileFromMessage(final Message msg) {
		try {
			final String path = initDownloadPhase(msg.getSender(), msg
					.getFile().toString());
			Thread tdown = new Thread() {
				@Override
				public void run() {
					try {
						File f = msg.getFile();
						FileWriter fw = new FileWriter(path + "/" + f.getName());
						fw.flush();
						fw.close();
						// TODO .. check why file doesn't contain anything...
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			};
			tdown.start();
		} catch (Exception e) {
			System.out.println("download cancelled");
			e.printStackTrace(System.err);
		}
	}

	/**
	 * This tiny method just asks if you want to download the message and let
	 * you choose where you want to store it.
	 * 
	 * @return path for file which is downloaded
	 */
	private String initDownloadPhase(String sender, String filename)
			throws Exception {
		String path = ".";

		FileAcceptDialog fad = new FileAcceptDialog(null, sender, filename);
		fad.setVisible(true);

		while (fad.isVisible()) {
			System.out.println("waiting...");
		}
		if (fad.getAcceptingState()) {
			JFileChooser jfc = new JFileChooser();
			jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			if (jfc.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
				path = jfc.getSelectedFile().getAbsolutePath();
				System.out.println("file-download path changed to: " + path);
			} else {
				throw new Exception(
						"user didn't accept the file-download .. closed FileChooser");
			}

		} else {
			throw new Exception("user didn't accept the file-download!");
		}

		return path;
	}

	/**
	 * If a new userlist is recieved, this method converts the userlist-string
	 * into a ListModel and makes it visible in the GUI!
	 * 
	 * @param users
	 *            ... the users in for of a String (split by two pipes ("||"))
	 * 
	 */
	private void newUserList(String users) {
		StringTokenizer stz = new StringTokenizer(users, "||");
		DefaultListModel dlm = new DefaultListModel();
		try {
			String user = "";
			while (stz.hasMoreTokens()) {
				user = stz.nextToken();
				dlm.addElement(new ListEntry(user));
			}
			System.out.println("new user list: " + dlm.toString());
			mw.setNewListModel(dlm);
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
	}

}
