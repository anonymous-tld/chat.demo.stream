package messages;

import java.io.File;
import java.io.Serializable;

/**
 * This class is the "Message" .. the JESUS of chatting.<br>
 * It is responsible for all message-and file transfers.<br> - each time a
 * message is sent, a new instance of Message is created, sent to the reciever
 * and deserialized on the other side to be further processed.
 * 
 * @author suso
 * 
 */
public class Message implements Serializable {

	// serialVersionUID .. for serializing and deserializing
	static final long serialVersionUID = 1;

	// the text of the message
	private String text;

	// the sender of the message
	private String sender;

	// the recipiant of the message
	private String recipiant;

	// the ip of the reciever
	private String ip;

	// the file which is sent with the message
	private File file;

	/**
	 * Constructor of class Message, every message is instanciated like this.
	 * 
	 * @param sender
	 *            ... the sender of the message
	 * @param recipiant
	 *            ... the reciever of the message
	 * @param text
	 *            ... the text of the message
	 */
	public Message(String sender, String recipiant, String text, File file) {
		this.text = text;
		this.recipiant = recipiant;
		this.sender = sender;
		this.file = file;
	}

	/**
	 * 
	 * @return text of the message
	 */
	public String getText() {
		return text;
	}

	/**
	 * 
	 * @return sender of the message
	 */
	public String getSender() {
		return sender;
	}

	/**
	 * 
	 * @return recipiant of the message
	 */
	public String getRecipiant() {
		return recipiant;
	}

	// unsafe method .. should be done some other way!
	/**
	 * sets sender of the message... bäh .. BAD METHOD!
	 */
	public void setSender(String ip) {
		this.sender = ip;
	}

	/**
	 * 
	 * @param ip
	 *            ... ip adress of the reciever
	 */
	public void setIP(String ip) {
		this.ip = ip;
	}

	/**
	 * 
	 * @return ip adress of reciever (ipV4 .. as a String)
	 */
	public String getIP() {
		return this.ip;
	}

	/**
	 * 
	 * @return file, which is sent in the message
	 */
	public File getFile() {
		return this.file;
	}

}
