package gui.comp;

import javax.swing.Icon;
import javax.swing.ImageIcon;

public class ListEntry {

	public final Icon ico = new ImageIcon("graphics/development/Host16.gif");

	private String text;

	public ListEntry(String text) {
		this.text = text;
	}

	public String getText() {
		return this.text;
	}

}
