package gui.comp;

import java.awt.Graphics;
import java.util.Vector;

import javax.swing.JList;
import javax.swing.ListModel;

public class JIRCList extends JList {

	
	private static final long serialVersionUID = 1L;

	@Override
	protected void paintComponent(Graphics g) {
		if (ui != null) {
			Graphics scratchGraphics = (g == null) ? null : g.create();
			try {
				ui.update(scratchGraphics, this);
			} finally {
				scratchGraphics.dispose();
			}
		}
	}

	public JIRCList() {

	}

	public JIRCList(ListModel dataModel) {
		super(dataModel);
	}

	public JIRCList(Object[] listData) {
		super(listData);
	}

	public JIRCList(Vector<?> listData) {
		super(listData);
	}

}
