package gui.comp;

import javax.swing.Icon;
import javax.swing.JButton;

public class ToolButton extends JButton {

	private static final long serialVersionUID = 1L;

	public ToolButton(String text, Icon ico) {
		super(text, ico);
	}

	public ToolButton(){
		
	}
	
}
