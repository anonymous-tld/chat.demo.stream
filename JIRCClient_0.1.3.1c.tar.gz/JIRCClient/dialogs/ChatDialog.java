package dialogs;

import gui.comp.ToolButton;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import worker.ChatSessionManager;
import worker.MWorker;

/**
 * This code was edited or generated using CloudGarden's Jigloo SWT/Swing GUI
 * Builder, which is free for non-commercial use. If Jigloo is being used
 * commercially (ie, by a corporation, company or business for any purpose
 * whatever) then you should purchase a license for each developer using Jigloo.
 * Please visit www.cloudgarden.com for details. Use of Jigloo implies
 * acceptance of these licensing terms. A COMMERCIAL LICENSE HAS NOT BEEN
 * PURCHASED FOR THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED LEGALLY FOR
 * ANY CORPORATE OR COMMERCIAL PURPOSE.
 */
public class ChatDialog extends javax.swing.JDialog {

	static final long serialVersionUID = 1;

	private JPanel jPanel1;

	private JScrollPane jScrollPane1;

	private JMenuItem MiExit;

	private JMenuItem BtSendFile;

	private JMenu ActionMenu;

	private JMenuBar ChatMenuBar;

	private JTextArea ta;

	private ToolButton btSend;

	private JTextField tfInput;

	private String nic;

	private String other;

	private MWorker mw;

	private ChatSessionManager csm;

	public ChatDialog(String me, String other, MWorker mw,
			ChatSessionManager csm) {
		this.nic = me;
		this.other = other;
		this.mw = mw;
		this.csm = csm;
		this.setTitle("JIRC session with: " + other);
		initGUI();
	}

	private void initGUI() {
		try {
			BorderLayout thisLayout = new BorderLayout();
			getContentPane().setLayout(thisLayout);
			{
				ChatMenuBar = new JMenuBar();
				setJMenuBar(ChatMenuBar);
				{
					ActionMenu = new JMenu();
					ChatMenuBar.add(ActionMenu);
					ActionMenu.setText("actions");
					{
						BtSendFile = new JMenuItem(new ImageIcon(
						"graphics/general/Edit16.gif"));
						ActionMenu.add(BtSendFile);
						BtSendFile.setText("send file");
						BtSendFile.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent evt) {
								BtSendFileActionPerformed(evt);
							}
						});
					}
					{
						MiExit = new JMenuItem(new ImageIcon(
						"graphics/general/Stop16.gif"));
						ActionMenu.add(MiExit);
						MiExit.setText("close");
						MiExit.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent evt) {
								MiExitActionPerformed(evt);
							}
						});
					}
				}
			}
			this.addWindowListener(new WindowAdapter() {
				@Override
				public void windowClosing(WindowEvent evt) {
					rootWindowClosing(evt);
				}
			});
			{
				jPanel1 = new JPanel();
				BorderLayout jPanel1Layout = new BorderLayout();
				jPanel1.setLayout(jPanel1Layout);
				getContentPane().add(jPanel1, BorderLayout.SOUTH);
				jPanel1.setPreferredSize(new java.awt.Dimension(394, 33));
				{
					tfInput = new JTextField();
					jPanel1.add(tfInput, BorderLayout.CENTER);
					tfInput.setPreferredSize(new java.awt.Dimension(394, 22));
				}
				{
					btSend = new ToolButton("send", new ImageIcon(
							"graphics/general/SendMail16.gif"));
					jPanel1.add(btSend, BorderLayout.EAST);

					btSend.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							onSend();
						}
					});
				}
			}
			{
				jScrollPane1 = new JScrollPane();
				getContentPane().add(jScrollPane1, BorderLayout.CENTER);
				{
					ta = new JTextArea();
					jScrollPane1.setViewportView(ta);
				}
			}

			/*
			 * my key-listener to send messages .. (can press enter instead of
			 * click on the send button!)
			 */
			tfInput.addKeyListener(new java.awt.event.KeyAdapter() {
				@Override
				public void keyPressed(java.awt.event.KeyEvent evt) {
					if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
						onSend();
					}
				}
			});

			this.setSize(333, 235);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void printMessage(String msg) {
		ta.setText(ta.getText() + "\n<" + other + "> says: " + msg);
		autoScroll();
	}

	/*
	 * this method just selects the last character in the text area .. and the
	 * scroll pane jumps to it's right position! .. don't got a real auto-scroll
	 * method up to now..
	 */
	private void autoScroll() {
		int select = ta.getText().length();
		ta.select(select, select);
	}

	public String getID() {
		return other;
	}

	private void onSend() {
		try {
			String msg = tfInput.getText();
			ta.setText(ta.getText() + "\n<" + nic + "> (you) says: " + msg);
			autoScroll();
			mw.sendMessage(other, msg);
			tfInput.setText("");
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
	}

	private void rootWindowClosing(WindowEvent evt) {
		System.out.println("this.windowClosing, event=" + evt);
		csm.removeSession(other);
	}

	@SuppressWarnings("static-access")
	private void BtSendFileActionPerformed(ActionEvent evt) {
		System.out.println("BtSendFile.actionPerformed, event=" + evt);
		JFileChooser jfc = new JFileChooser();

		if (jfc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
			try {
				File f = jfc.getSelectedFile();
				mw.sendFile(other, f);
			} catch (Exception e) {
				e.printStackTrace(System.err);
			}
		} else {

		}
	}

	private void MiExitActionPerformed(ActionEvent evt) {
		System.out.println("MiExit.actionPerformed, event=" + evt);
		csm.removeSession(other);
		this.setVisible(false);
	}

}
