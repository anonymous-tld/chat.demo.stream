package dialogs;

import com.cloudgarden.layout.AnchorConstraint;
import com.cloudgarden.layout.AnchorLayout;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * This code was edited or generated using CloudGarden's Jigloo SWT/Swing GUI
 * Builder, which is free for non-commercial use. If Jigloo is being used
 * commercially (ie, by a corporation, company or business for any purpose
 * whatever) then you should purchase a license for each developer using Jigloo.
 * Please visit www.cloudgarden.com for details. Use of Jigloo implies
 * acceptance of these licensing terms. A COMMERCIAL LICENSE HAS NOT BEEN
 * PURCHASED FOR THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED LEGALLY FOR
 * ANY CORPORATE OR COMMERCIAL PURPOSE.
 */
public class FileAcceptDialog extends javax.swing.JDialog {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JLabel LbText;

	private JPanel pan1;

	private JLabel lbQA;

	private JButton btOK;

	private JButton btNO;

	@SuppressWarnings("unused")
	private boolean accepted;

	public FileAcceptDialog(JFrame frame, String sender, String file) {
		super(frame);
		initGUI(sender, file);
	}

	private void initGUI(String sender, String file) {
		try {
			BorderLayout thisLayout = new BorderLayout();
			getContentPane().setLayout(thisLayout);
			{
				LbText = new JLabel();
				getContentPane().add(LbText, BorderLayout.NORTH);
				LbText.setText(sender + " wants to send you \"" + file + "\"!");
				LbText.setPreferredSize(new java.awt.Dimension(288, 26));
			}
			{
				pan1 = new JPanel();
				AnchorLayout pan1Layout = new AnchorLayout();
				pan1.setLayout(pan1Layout);
				getContentPane().add(pan1, BorderLayout.CENTER);
				pan1.setPreferredSize(new java.awt.Dimension(336, 189));
				{
					btNO = new JButton();
					pan1.add(btNO, new AnchorConstraint(441, 779, 879, 487,
							AnchorConstraint.ANCHOR_REL,
							AnchorConstraint.ANCHOR_REL,
							AnchorConstraint.ANCHOR_REL,
							AnchorConstraint.ANCHOR_REL));
					btNO.setText("NOPE");
					btNO.setPreferredSize(new java.awt.Dimension(84, 49));
					btNO.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							btNOActionPerformed(evt);
						}
					});
				}
				{
					btOK = new JButton();
					pan1.add(btOK, new AnchorConstraint(441, 463, 879, 171,
							AnchorConstraint.ANCHOR_REL,
							AnchorConstraint.ANCHOR_REL,
							AnchorConstraint.ANCHOR_REL,
							AnchorConstraint.ANCHOR_REL));
					btOK.setText("OK");
					btOK.setPreferredSize(new java.awt.Dimension(84, 49));
					btOK.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							btOKActionPerformed(evt);
						}
					});
				}
				{
					lbQA = new JLabel();
					pan1.add(lbQA, new AnchorConstraint(60, 1022, 286, 1,
							AnchorConstraint.ANCHOR_REL,
							AnchorConstraint.ANCHOR_REL,
							AnchorConstraint.ANCHOR_REL,
							AnchorConstraint.ANCHOR_REL));
					lbQA.setText("do you want to accept this?");
					lbQA.setPreferredSize(new java.awt.Dimension(294, 28));
				}
			}
			this.setSize(296, 172);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void btOKActionPerformed(ActionEvent evt) {
		System.out.println("btOK.actionPerformed, event=" + evt);
		accepted = true;
		this.setVisible(false);
	}

	private void btNOActionPerformed(ActionEvent evt) {
		System.out.println("btNO.actionPerformed, event=" + evt);
		accepted = false;
		this.setVisible(false);
	}

	public boolean getAcceptingState() {
		return accepted;
	}
}
