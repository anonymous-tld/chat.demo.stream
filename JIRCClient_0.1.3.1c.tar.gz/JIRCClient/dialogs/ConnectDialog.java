package dialogs;

import gui.ClientGUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 * This code was edited or generated using CloudGarden's Jigloo SWT/Swing GUI
 * Builder, which is free for non-commercial use. If Jigloo is being used
 * commercially (ie, by a corporation, company or business for any purpose
 * whatever) then you should purchase a license for each developer using Jigloo.
 * Please visit www.cloudgarden.com for details. Use of Jigloo implies
 * acceptance of these licensing terms. A COMMERCIAL LICENSE HAS NOT BEEN
 * PURCHASED FOR THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED LEGALLY FOR
 * ANY CORPORATE OR COMMERCIAL PURPOSE.
 */
public class ConnectDialog extends javax.swing.JDialog {
	static final long serialVersionUID = 1;

	private JLabel lbServerIP;

	private JTextField tfNic;

	private JLabel lbNic;

	private JLabel lbHeading;

	private JButton btCancel;

	private JButton btOK;

	private JTextField tfPort;

	private JTextField tfServerIP;

	private JLabel jLabel1;

	private ClientGUI gui;

	public ConnectDialog(JFrame frame, ClientGUI gui) {
		super(frame);
		initGUI();
		this.gui = gui;
	}

	private void initGUI() {
		try {
			{
				getContentPane().setLayout(null);
				this.setTitle("connect");
				{
					lbServerIP = new JLabel();
					getContentPane().add(lbServerIP);
					lbServerIP.setText("Server-IP");
					lbServerIP.setBounds(21, 77, 91, 28);
					lbServerIP.setHorizontalAlignment(SwingConstants.RIGHT);
				}
				{
					jLabel1 = new JLabel();
					getContentPane().add(jLabel1);
					jLabel1.setText("Server-port");
					jLabel1.setBounds(21, 105, 91, 28);
					jLabel1.setHorizontalAlignment(SwingConstants.RIGHT);
				}
				{
					tfServerIP = new JTextField();
					getContentPane().add(tfServerIP);
					tfServerIP.setBounds(119, 77, 168, 28);
				}
				{
					tfPort = new JTextField();
					getContentPane().add(tfPort);
					tfPort.setBounds(119, 105, 63, 28);
				}
				{
					btOK = new JButton();
					getContentPane().add(btOK);
					btOK.setText("OK");
					btOK.setBounds(70, 140, 63, 28);
					btOK.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {

							onBtOkAction(evt);
						}
					});
				}
				{
					btCancel = new JButton();
					getContentPane().add(btCancel);
					btCancel.setText("Cancel");
					btCancel.setBounds(133, 140, 119, 28);
					btCancel.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							btCancelActionPerformed(evt);
						}
					});
				}
				{
					lbHeading = new JLabel();
					getContentPane().add(lbHeading);
					lbHeading.setText("Please enter following information!");
					lbHeading.setBounds(7, 7, 294, 28);
					lbHeading.setHorizontalAlignment(SwingConstants.CENTER);
					lbHeading.setFont(new java.awt.Font("Dialog", 0, 14));
				}
				{
					lbNic = new JLabel();
					getContentPane().add(lbNic);
					lbNic.setText("Nicname");
					lbNic.setBounds(49, 49, 63, 28);
					lbNic.setHorizontalTextPosition(SwingConstants.RIGHT);
					lbNic.setHorizontalAlignment(SwingConstants.RIGHT);
				}
				{
					tfNic = new JTextField();
					getContentPane().add(tfNic);
					tfNic.setBounds(119, 49, 168, 28);
				}
			}
			this.setSize(333, 214);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void btCancelActionPerformed(ActionEvent evt) {
		System.out.println("btCancel.actionPerformed, event=" + evt);
		this.setVisible(false);
	}

	private void onBtOkAction(ActionEvent evt) {
		System.out.println("btOK.actionPerformed, event=" + evt);
		String nic = tfNic.getText();
		String ip = tfServerIP.getText();
		int port = Integer.parseInt(tfPort.getText());
		gui.login(nic, ip, port);
		this.setVisible(false);
	}
}
