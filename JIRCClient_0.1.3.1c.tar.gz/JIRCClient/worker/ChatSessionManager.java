package worker;

import java.util.Enumeration;
import java.util.Vector;

import dialogs.ChatDialog;

public class ChatSessionManager {

	private MWorker mw;

	/**
	 * 
	 * @param mw
	 */
	public ChatSessionManager(MWorker mw) {
		this.mw = mw;
	}

	private Vector<ChatDialog> chatSessions = new Vector<ChatDialog>();

	/**
	 * 
	 * @param id
	 * @param nic
	 */
	public void addSession(String id, String nic) {
		Enumeration e = chatSessions.elements();
		while (e.hasMoreElements()) {
			ChatDialog cd = (ChatDialog) e.nextElement();

			if (cd.getID().equals(id)) {
				return;
			}
		}
		ChatDialog cdn = new ChatDialog(nic, id, mw, this);
		cdn.setVisible(true);
		chatSessions.add(cdn);

	}

	/**
	 * 
	 * @param id
	 */
	public void removeSession(String id) {
		for (int i = 0; i <= chatSessions.size(); i++) {
			ChatDialog cd = chatSessions.get(i);
			if (cd.getID().equals(id)) {
				chatSessions.remove(i);
			}
		}
	}

	/**
	 * 
	 * @param id
	 * @param msg
	 */
	public void incomingMessage(String id, String msg) {
		Enumeration e = chatSessions.elements();
		while (e.hasMoreElements()) {
			ChatDialog cd = (ChatDialog) e.nextElement();
			if (cd.getID().equals(id)) {
				cd.printMessage(msg);
				return;
			}
		}
		addSession(id, mw.getNic());
		incomingMessage(id, msg);
	}

}
