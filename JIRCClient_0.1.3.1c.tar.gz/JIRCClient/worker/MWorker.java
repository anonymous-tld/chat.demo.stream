package worker;

import gui.ClientGUI;

import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.DefaultListModel;

import messages.ClientMessageHandler;
import messages.Message;

public class MWorker extends Thread {

	private int port;

	private ServerSocket serv;

	private String serverIP;

	private String nic;

	private DefaultListModel dlm = new DefaultListModel();

	private ClientGUI gui;

	private ClientMessageHandler cmh;

	private final String fileTransferID = "$$file-transfer-0.1";

	public DefaultListModel getListModel() {
		return dlm;
	}

	/**
	 * This tiny method updates the userlist in the GUI.
	 * 
	 * @param dlm
	 *            ... the new DefaultListModel (list of available users)
	 */
	public void setNewListModel(DefaultListModel dlm) {
		this.dlm = dlm;
		gui.updateUserList();
	}

	/**
	 * The constructor of MWorker.. <br>
	 * Creates new Instantce of MWorker!
	 * 
	 * @param port
	 *            ... the port on which messages will be sent
	 * @param serverIP
	 *            ... the ip-adress of the server you're communicating with
	 * @param nic
	 *            ... the client nickname
	 * @param gui
	 *            ... the ClientGUI
	 */
	public MWorker(int port, String serverIP, String nic, ClientGUI gui) {
		this.port = port;
		this.serverIP = serverIP;
		this.nic = nic;
		this.gui = gui;
		this.cmh = ClientMessageHandler.getAClientMessageHandler(this);
		try {
			this.serv = new ServerSocket(port);
			this.start();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method just sends a logon-message to the server <br>
	 * (ip-adress configured when created new MWorker object!)
	 * 
	 */
	public void logon() {
		try {
			Socket s = new Socket(serverIP, port);

			Message message = new Message(nic, serverIP, "logon-message", null);

			ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());

			oos.writeObject(message);

			oos.flush();

			oos.close();

			s.close();
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
	}

	/**
	 * This method is the main message-sending method!<br>
	 * 
	 * @param recipiant
	 *            ... username of the user you want to send the message to!
	 * @param msg
	 *            ... the message you want to send in form of a String.
	 * @throws Exception
	 */
	public void sendMessage(String recipiant, String msg) throws Exception {
		try {
			Socket s = new Socket(serverIP, port);

			Message message = new Message(nic, recipiant, msg, null);

			ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());

			oos.writeObject(message);

			oos.flush();

			oos.close();

			s.close();
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * This is the main file-sending method!
	 * 
	 * @param recipiant
	 *            ... username of the user you want to send the message to!
	 * @param file
	 *            ... the File you want to send to a user (java.io.File)
	 * @throws Exception
	 */
	public void sendFile(String recipiant, File file) throws Exception {
		// just an alpha-idea of the file-sending method ...
		try {
			Socket s = new Socket(serverIP, port);
			Message fileMsg = new Message(nic, recipiant, fileTransferID, file);
			ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
			oos.writeObject(fileMsg);
			oos.flush();
			oos.close();
			s.close();
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * This message just reads a Message-object from a Socket!
	 * 
	 * @param s
	 *            ... the socket that sent data
	 */
	private void inputData(Socket s) {
		try {

			ObjectInputStream ois = new ObjectInputStream(s.getInputStream());

			Object o = ois.readObject();

			Message message = (Message) o;

			ois.close();

			cmh.handleMessage(message);

		} catch (Exception e) {

			e.printStackTrace(System.err);
			System.exit(0);

		}
	}

	/**
	 * .. the Thread which checks always for incoming data!
	 */
	@Override
	public void run() {
		Socket is = null;
		while (!isInterrupted()) {
			try {
				is = serv.accept();
				if (is != null) {
					inputData(is);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * BE AWARE! - THIS METHOD SHOULDN'T BE USED ANY LONGER!
	 * 
	 * @return the localhost ip-adress (ipV4) .. in form of a String!
	 * @throws Exception
	 */
	public String getIPAdress() throws Exception {
		InetAddress inet4 = InetAddress.getLocalHost();

		String ip = inet4.getHostAddress();

		return ip;
	}

	/**
	 * 
	 * @return the client-nickname
	 */
	public String getNic() {
		return this.nic;
	}

	/**
	 * 
	 * @return the ClientGUI-object the MWorker is working with!
	 */
	public ClientGUI accessGUI() {
		return gui;
	}

}
