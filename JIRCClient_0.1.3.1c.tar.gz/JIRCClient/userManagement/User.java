package userManagement;

public class User {

	private String nic;

	private String ip;

	public User(String nic, String ip) {
		this.setNic(nic);
		this.setIp(ip);
	}

	private void setNic(String nic) {
		this.nic = nic;
	}

	public String getNic() {
		return nic;
	}

	private void setIp(String ip) {
		this.ip = ip;
	}

	public String getIp() {
		return ip;
	}

}
