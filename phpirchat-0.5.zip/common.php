<?php

/********************************************************************************
 * Server variables: MySQL, IRC
*********************************************************************************/

$mysql_host = "localhost";	// do i need
$mysql_user = "test";		// to explain
$mysql_pass = "";		// this?
$mysql_db = "test";		// my guess is no...

$serv_addr = "127.0.0.1"; 		// the irc server dns or ip
$serv_name = "irc.platonium.com"; 	// !! the irc server name (for example when connecting to serv_addr=127.0.0.1 and you see 'irc.platonium.com') case insensitive
$serv_port = 6667;			// the irc server port, normally 6667.

$channels[] = "platonium";		// change this to your channel,
//$channels[] = "puchforum";		// or uncomment the rest to let
//$channels[] = "jongeren";		// the user choose the channel

$hide_motd = true;		// false = show the Message of the Day, true = don't show motd...
				// the motd might be too long, not usefull or sth else for u... so set it to true then...
$chat_newscr = true;		// opens a new screen by default when pressing the chat button

/********************************************************************************
 * Layout variables: Colors, fonts, CSS
*********************************************************************************/

$fontsize = 10;		// the font size of all the pages
$fontfamily = "'helvetica', 'lucida', 'arial'";	// the font family(s) of all the pages. *! Within the dubble quotes, supply single quotes around each family !*

$page_bg  = "#000000"; 		// page background color
$chan_bg  = "#000000"; 		// channel frame background color
$chan_fg  = "#AACCAA"; 		// channel frame foreground color
$input_bg = "#303030"; 		// background color of the input text, the buttons, and the color chooser
$table_border = "#AACCAA"; 	// border color of the table
$page_fg  = "#AACCAA"; 		// page foreground/text color

 $ircColors[0] = "#FFFFFF"; // white
 $ircColors[1] = "#000000"; // black
 $ircColors[2] = "#000080"; // dark blue
 $ircColors[3] = "#008000"; // dark green -> standard for join/part/quit
 $ircColors[4] = "#FF0000"; // red	 -> standard for error/disconnect
 $ircColors[5] = "#800000"; // dark red	 -> standard for notices
 $ircColors[6] = "#FF00FF"; // purple	 -> standard for (ctcp) Actions
 $ircColors[7] = "#FF8000"; // orange	 -> standard for server messages (like topics, names, modes)
 $ircColors[8] = "#FFFF00"; // yellow
 $ircColors[9] = "#00FF00"; // green
$ircColors[10] = "#008080"; // dark cyan
$ircColors[11] = "#00FFFF"; // cyan
$ircColors[12] = "#0000FF"; // blue
$ircColors[13] = "#800080"; // dark purple
$ircColors[14] = "#808080"; // dark grey
$ircColors[15] = "#C0C0C0"; // light grey


/* The css part that gets included on every page, add ur own wishes here ;) */
$css = <<<EOF
<style type="text/css">

body,tr,td,iframe {
    font-family: $fontfamily;
    font-size: {$fontsize}pt;
}
</style>

EOF;

/********************************************************************************
 * That's all, have fun PHP chatting ;)
*********************************************************************************/

?>