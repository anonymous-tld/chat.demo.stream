<html>
<head>
<title>PHP IRC Chat</title>
<?php
include("common.php");
echo $css;
?>
<script language="JavaScript">

function startchat() {
    var nick = document.input.username.value;
    var channel = "";
<?php
if (count($channels) > 1) {
    echo <<<EOF
    var a = document.input.channel.selectedIndex;
    if (a > -1) {
	channel = document.input.channel.options[a].value;
    }
EOF;
} else {
    echo <<<EOF
    channel = document.input.channel.value;
EOF;
}
?>    
    if (channel != "" && nick != "") {
	var url = "chat.php?username="+nick+"&channel="+channel;
	if (document.input.newwin.value) {
	    window.open(url, 'chat', 'height=450,width=720,location=no,menubar=no,toolbar=no,scrollbars=auto');
	} else {
	    window.location.href=url;
	}
    }
}

</script>
</head>
<body bgcolor="<?php echo "$page_bg"; ?>" text="<?php echo "$page_fg"; ?>">

<form action="javascript: startchat();" name="input">
<table cellspacing="0" cellpadding="0">
    <tr>
	<td>
	    Nickname:
	</td>
	<td>
	    <input type="text" name="username">
	</td>
	<td rowspan="2">
	    <input type="submit" value="chat!">
	</td>
    </tr>
<?php
if (count($channels) > 1) {
echo <<<EOF
    <tr>
	<td>
	    Channel:
	</td>
	<td>
	    <select name="channel">
EOF;
foreach ($channels as $chan) {
    echo <<<EOF
		<option value="$chan"> #$chan

EOF;
}
echo <<<EOF
	    </select>
	</td>
    </tr>
EOF;
} else {
    echo <<<EOF
<input type="hidden" name="channel" value="$channels[0]">

EOF;
}
?>
    <tr>
	<td>&nbsp;</td>
	<td colspan="2">
	    <input type="checkbox" name="newwin" value="true"<?php if ($chat_newscr) { echo " CHECKED"; } ?>>Open in new window
	</td>
    </tr>
</table>
</form><br>
<h2>A little help:</h2>
<ul>
<li>The little green dot next to the 'send' button indicates if the command was successfully inserted into the mysql database for further proccessing (red=bad...)
<li>If you want to read back to the beginning, first press the 'stop' button, to stop the script from scrolling down automaticly.
<li>When you want to use a little color in your text, press one of the colored squares where it says 'color chooser', or type: %C(digit)[,(digit)] where (digit) stands for a number between 0 and 15. the [,(digit)] is optional and means a background text.
<li>The command used for actions (<font color="<?php echo "$ircColors[6]"; ?>">* sgorpi hits henk with a large trout.</font>) is this: /me hits henk with a large trout.
<li>If you get some text like: <font color="<?php echo "$ircColors[5]"; ?>">-sgorpi- hi there</font>, you've just recieved a 'notice'. you can notice back by typing: /notice sgorpi hi sgorpi.
<li>If you get some text like: &lt;<font color="<?php echo "$ircColors[7]"; ?>">sgorpi-&gt;yournick</font>&gt; welcome to the chat. &nbsp;&nbsp;&nbsp;You've just recieved a private message. message back with the command: /msg sgorpi thank you


</body>
</html>
