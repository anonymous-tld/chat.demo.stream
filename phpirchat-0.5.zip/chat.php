<?php
    if (preg_match("/Mozilla\/\d.+Compatible; MSIE/i", $HTTP_SERVER_VARS['HTTP_USER_AGENT']) && !preg_match("/Opera/i", $HTTP_SERVER_VARS['HTTP_USER_AGENT'])) {
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
    } else {
        header('Expires: 0');
        header('Pragma: no-cache');
    }
include("common.php");
echo <<<EOF
<html>
<head>
<title>PHP IRC Chat</title>
$css
<script language="JavaScript"><!--;

EOF;
$user = $HTTP_GET_VARS['username'];
$id = time();
$channel = $HTTP_GET_VARS['channel'];
if (!$channel) {
    $channel = $channels[0];
}
echo <<<EOF
user = "$user";
id = $id;
channel = "%23$channel";

EOF;
?>

commandHist = new Array();
commandNr = 0;

function send() {
    var cmd = document.input.command.value;
    var a = commandHist.unshift(cmd);
    if (a > 20) {
	commandHist.pop();
    }
    commandNr = 0;
    cmd = escape(cmd);
    self.passcmnd.location = "pcmnd.php?username="+user+"&id="+id+"&cmnd="+cmd+"&channel="+channel;
    document.input.command.value=""; // empty
//    alert("hey");
}
function choseColor(color) {
    document.input.command.value += "%C"+color;
}

function nixreload(namelist) {
    if (namelist) {
	var a=0,b=0;
	for (a = document.nicks.nix.options.length; a > 0; a--) {
	    document.nicks.nix.options[a] = null;
	}
	names = namelist.split(":");
	names.sort();
	for (a = 0; a < names.length; a++) {
	    if (names[a].length > 0) {
		document.nicks.nix.options[b] = new Option(names[a], names[a]);
	        b++;
	    }
	}
    }
    return true;
}

interID = -1;

function scrollen() {
    self.out.scrollBy(0,25)
}
function scrl(what) {
    if (what == 1) {
	if (interID == -1) {
	    clearInterval(interID);
	    interID = -1;
	    interID = setInterval("scrollen()", 250); // scroll down om de 250 ms;
	}
    } else {
	clearInterval(interID);
	interID = -1;
    }
}

function do_MorN(type) {
    var a;
    var act = "/msg ";
    if (type == 2) { act = "/notice "; }
    a = document.nicks.nix.selectedIndex;
    nick = document.nicks.nix.options[a].value;
    nick = nick.replace(/[\@\+\%]/, "");
    document.input.command.value = act + nick + " ";
}
function do_whois() {
    a = document.nicks.nix.selectedIndex;
    nick = document.nicks.nix.options[a].value;
    nick = nick.replace(/[\@\+\%]/, "");
    document.input.command.value = "/whois " + nick;
    send();
}
function displayCommand(relElem) {
    commandNr += relElem;
    if (commandNr < 0) { commandNr = commandHist.length-1; }
    if (commandNr >= commandHist.length) { commandNr = 0; }
    document.input.command.value = commandHist[commandNr];
}
//--></script>

</head>
<body bgcolor="<?php echo "$page_bg"; ?>" text="<?php echo "$page_fg"; ?>">

<table cellspacing="1" cellpadding="0" bgcolor="<?php echo $table_border; ?>">
    <tr>
	<td bgcolor="<?php echo $chan_bg; ?>">
	    <iframe frameborder="0" height="350" width="550" name="out" src="main.php?username=<?php echo "$user&channel=$channel&id=$id&"; ?>" valign="bottom" marginwidth="0" marginheight="0">Sorry your browser doesn't support this :S</iframe>
	</td>
	<td bgcolor="<?php echo $chan_bg; ?>" width="150" valign="top" align="center">
	    ppl in #<?php echo $channel ?><br>
	    <form name="nicks" onSubmit="return false;" action="javascript: return false">
		<select name="nix" size="15" style="width: 150; border-width: 0; border-style: solid; border-color: <?php echo "$chan_bg; font-family: $fontfamily; color: $chan_fg; background-color: $chan_bg;"; ?>"></select>
	    </form>
	</td>
    </tr>
    <tr>
	<td align="center" bgcolor="<?php echo $input_bg; ?>">
	    <form name="input" onSubmit="send();return false;" style="margin:0pt; padding:0pt;">
	    <input type="text" name="command" size="68"><input type="button" value="Send" onClick="send()">
	    <iframe frameborder="0" height="5" width="5" src="pcmnd.php" name="passcmnd" marginwidth="0" marginheight="0"></iframe>
	    <input type="button" value="<" onClick="displayCommand(1)" style="width: 10pt; height: 16pt;">
	    <input type="button" value=">" onClick="displayCommand(-1)" style="width: 10pt; height: 16pt;">
	    </form>
	</td>
	<td bgcolor="<?php echo $input_bg; ?>" rowspan="2" align="right">
	    <table width="100%" cellspacing="0" cellpadding="0">
		<tr><td valign="top">
		    <input type="button" value="whois" onClick="do_whois();"><br>
		</td><td align="right" valign="top">
		    <input type="button" value="msg" onClick="do_MorN(1);"><br>
		    <input type="button" value="notice" onClick="do_MorN(2);">
		</td></tr>
	    </table>
	</td>
    </tr>
    <tr>
	<td align="center" bgcolor="<?php echo $input_bg; ?>" valign="middle">
	    <table width="100%" cellspacing="0" cellpadding="0"><tr><td>
	    Auto Scrolling:
	    <input type="button" value="Stop" onClick="scrl(0)">
	    <input type="button" value="Start" onClick="scrl(1)">
	    <!-- color chooser table -->
	    </td><td align="right">
	    <table cellspacing="1" cellpadding="0">
		<tr>
		    <td rowspan="2">Color chooser:</td>
		    <td height="6" width="10" bgcolor="<?php echo "$ircColors[0]"; ?>" onClick="choseColor(0)"></td>
		    <td height="6" width="10" bgcolor="<?php echo "$ircColors[1]"; ?>" onClick="choseColor(1)"></td>
		    <td height="6" width="10" bgcolor="<?php echo "$ircColors[2]"; ?>" onClick="choseColor(2)"></td>
		    <td height="6" width="10" bgcolor="<?php echo "$ircColors[3]"; ?>" onClick="choseColor(3)"></td>
		    <td height="6" width="10" bgcolor="<?php echo "$ircColors[4]"; ?>" onClick="choseColor(4)"></td>
		    <td height="6" width="10" bgcolor="<?php echo "$ircColors[5]"; ?>" onClick="choseColor(5)"></td>
		    <td height="6" width="10" bgcolor="<?php echo "$ircColors[6]"; ?>" onClick="choseColor(6)"></td>
		    <td height="6" width="10" bgcolor="<?php echo "$ircColors[7]"; ?>" onClick="choseColor(7)"></td>
		</tr>
		<tr>
		    <td height="6" width="10" bgcolor="<?php echo "$ircColors[8]"; ?>" onClick="choseColor(8)"></td>
		    <td height="6" width="10" bgcolor="<?php echo "$ircColors[9]"; ?>" onClick="choseColor(9)"></td>
		    <td height="6" width="10" bgcolor="<?php echo "$ircColors[10]"; ?>" onClick="choseColor(10)"></td>
		    <td height="6" width="10" bgcolor="<?php echo "$ircColors[11]"; ?>" onClick="choseColor(11)"></td>
		    <td height="6" width="10" bgcolor="<?php echo "$ircColors[12]"; ?>" onClick="choseColor(12)"></td>
		    <td height="6" width="10" bgcolor="<?php echo "$ircColors[13]"; ?>" onClick="choseColor(13)"></td>
		    <td height="6" width="10" bgcolor="<?php echo "$ircColors[14]"; ?>" onClick="choseColor(14)"></td>
		    <td height="6" width="10" bgcolor="<?php echo "$ircColors[15]"; ?>" onClick="choseColor(15)"></td>
		</tr>
	    </table>
	    </td></tr></table>
	    <!-- end -->
	</td>
    </tr>
</table>

</body>