<?php
    if (preg_match("/Mozilla\/\d.+Compatible; MSIE/i", $HTTP_SERVER_VARS['HTTP_USER_AGENT']) && !preg_match("/Opera/i", $HTTP_SERVER_VARS['HTTP_USER_AGENT'])) {
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
    } else {
        header('Expires: 0');
        header('Pragma: no-cache');
    }

include("common.php");

$channel = $HTTP_GET_VARS['channel'];
echo "$channel <br>";
if (!$channel) {
    $channel = $channels[0];
}

$user = $HTTP_GET_VARS['username'];
$id = $HTTP_GET_VARS['id'];



$nick = $HTTP_GET_VARS['username'];
//$serv_addr = "127.0.0.1";
//$serv_port = 6667;

echo <<<EOF
<html>
<head>
<title>PHP IRC Chat output page</title>
$css
</head>
<body bgcolor="$chan_bg" text="$chan_fg">

EOF;

$smily_code = array("/:-?\)/", 
		    "/;b/", 
		    "/:-?P/i", 
		    "/;-?\)/i", 
		    "/:-?\(/", 
		    "/:-?D/i",
		    "/:-?\|/i",
		    "/\(y\)/i",
		    "/:-?S/i");
$smily_repl = array("<img src='pics/ng-smile.gif' width=15 height=15>",
		    "<img src='pics/ng-bsmile.gif' width=15 height=15>",
		    "<img src='pics/ng-psmile.gif' width=15 height=15>",
		    "<img src='pics/ng-wink.gif' width=15 height=15>",
		    "<img src='pics/ng-sad1.gif' width=15 height=15>",
		    "<img src='pics/ng-dsmile.gif' width=15 height=15>",
		    "<img src='pics/ng-amazed.gif' width=15 height=15>",
		    "<img src='pics/ng-thumbsup.gif' width=15 height=15>",
		    "<img src='pics/ng-sad2.gif' width=15 height=15>");

@set_time_limit(3600); // ten minutes execution time, when user says or does something, this is reset with 10 min.
/* ** ** set_time_limit() doesn't seem to have any effect whatsoever... ** ** */

register_shutdown_function("einde");

echo <<<EOF
Your nick will be: $nick and your id is: $id. You will join $channel.
<script language="JavaScript"><!--; parent.scrl(1); //--></script>
<br><br>Connecting to $serv_addr...

EOF;


$socket = fsockopen($serv_addr, $serv_port, $errno, $errstr);

if ($socket < 0) { echo "failed... $errno: $errstr"; return; }
else { echo "Connected."; }

socket_set_blocking($socket, false);

echo "<br>";
echo "<script language='JavaScript'>\n<!--;\n parent.scrl(1);\n //-->\n</script>";
flush(); //output this;

$out = "";
$login = 0;
$loggedin = false;
$inchan = false;
$nicktry = 0;
$signontime = time();
function einde() {
    global $socket,$signontime;
    if ($socket) {
	@fputs($socket, "QUIT :platonium PHP chat\r\n");
	@fclose($socket);
    }
    mysql_query("DELETE FROM phpchat WHERE username = '$user' AND id = '$id'");
    $signofftime = time();
    $onlinetime = $signofftime-$signontime;

    $d1 = (floor($onlinetime/3600) < 10) ? "0".floor($onlinetime/3600) : floor($onlinetime/3600);
    $rest = $onlinetime%3600;
    $d1 .= (floor($rest/60) < 10) ? ":0".floor($rest/60) : ":".floor($rest/60);;
    $rest = $rest%60;
    $d1 .= ($rest < 10) ? ":0".$rest : ":".$rest;
    echo "Signed on at: " . date("H:i:s d-m-Y", $signontime) . ", Signed off at: " . date("H:i:s d-m-Y", $signofftime) . "<br>";
    echo "Online time: $d1 ($onlinetime seconds)";
}
function retn_color($fg, $bg) {
    global $ircColors;
    if ($bg != -1) {
    	return "<font style='color: ".$ircColors[$fg]."; background-color: ".$ircColors[$bg].";'>";
    } else {
	return "<font style='color: ".$ircColors[$fg].";'>";
    }
}
function smile_repl($string) {
    global $smily_code, $smily_repl, $ircColors;
    $string = preg_replace("/\003(\d+),(\d+)/e", "retn_color($1,$2)", $string);
    $string = preg_replace("/\003(\d+)/e", "retn_color($1, -1)", $string);
    $string = preg_replace("/\003/", "<font style='color: $page_fg; background-color: $page_bg;'>", $string);
    for ($a = 0; $a < substr_count($string, "<font"); $a++) {
	$string .= "</font>";
    }
    return preg_replace($smily_code, $smily_repl, $string);    
}

$link = mysql_connect($mysql_host, $mysql_user, $mysql_pass);
mysql_select_db($mysql_db);

while($socket) {
    $out = fgets($socket, 4096);
    $out = rtrim($out);
    if (strlen($out) > 1) {
	if (preg_match("/PING (:.+)/", $out, $matches)) {
	    fputs($socket, "PONG $matches[1]\r\n");
	    //echo "ping-pong<br>";

	} elseif (preg_match("/.+433.+:nickname is already in use/i", $out)) {
	    $nick .= rand(0,9);
	    echo "<font color='$ircColors[7]'>Nick already in use, changing to: $nick</font><br>\n";
	    fputs($socket, "NICK :$nick\r\n");

	} elseif (preg_match("/:([^\s]+) NOTICE ([^\s]+) :(.+)/", $out, $matches)) {
	    if (preg_match("/$nick/i", $matches[3])) { $matches[1] = "<b>$matches[1]</b>"; }
	    $src = $matches[1]; $text = smile_repl(htmlspecialchars($matches[3]));
	    if (preg_match("/([^!]+)!.+/", $src, $matches)) { $src = $matches[1]; }
	    echo "<font color='$ircColors[5]'>-$src- $text</font><br>";

	} elseif (preg_match("/:$serv_name (\d+) ([^\s]+) (.+)/i", $out, $matches)) {
	    if ($matches[1] == "376") { /*end of motd*/ $loggedin = true; }
	    elseif ($matches[1] == "353") { //names
		if (preg_match("/= (\#[^\s]+) :(.+)/", $matches[3], $match)) {
		    echo "<font color='$ircColors[7]'>--- People in $match[1]: ";
		    $namen = $match[2];
		    //$namen = str_replace("@", "", $match[2]);
		    //$namen = str_replace("%", "", $namen);
		    //$namen = str_replace("+", "", $namen);
		    $names = preg_split("/\s+/", $namen);
		    natcasesort($names);
		    foreach($names as $name) {
			echo "$name, ";
			$nicklist['$match[1]'] .= "$name:";
		    }
		    echo "</font><br>";
		}

	    } elseif ($matches[1] == "366") { // endofnames
		if (preg_match("/(#[^\s]+)/", $matches[3], $match)) {
		    $namelist = $nicklist['$match[1]'];
		    echo "\n<script language='JavaScript'>\n<!--;\n\nparent.nixreload(':$namelist');\n\n//-->\n</script>\n\n";
		    $nicklist['$match[1]'] = "";
		    flush();
		}
	    } elseif ($matches[1] == "332") {
		if (preg_match("/(#[^\s]+) :(.+)/", $matches[3], $match)) {
		    echo "<font color='$ircColors[7]'>--- Topic for $match[1] is: $match[2]</font><br>";
		}
	    } elseif (($matches[1] == "372" || $matches[1] == "375") && $hide_motd) {
		// do nothing, the motd doesn't have to be displayed...
	    } elseif ($matches[1] == "317") {
		// whois idle time and signon time
		if (preg_match("/([^\s]+)\s+(\d+)\s+(\d+)\s+:.+/", $matches[3], $match)) {
		    $d1 = (floor($match[2]/3600) < 10) ? "0".floor($match[2]/3600) : floor($match[2]/3600);
		    $rest = $match[2]%3600;
		    $d1 .= (floor($rest/60) < 10) ? ":0".floor($rest/60) : ":".floor($rest/60);;
		    $rest = $rest%60;
		    $d1 .= ($rest < 10) ? ":0".$rest : ":".$rest;
		    $d2 = date("Y-m-d H:i:s", $match[3]);
		    echo "<font color='$ircColors[12]'>-$serv_name- $match[1] idle: $d1, signon: $d2</font><br>";
		}
	    } else {
		echo "<font color='$ircColors[12]'>-$serv_name- $matches[3]</font><br>";
	    }

	} elseif (preg_match("/Closing Link(.*)/i", $out, $matches)) {
	    echo "<font color='$ircColors[4]'>Disconnected$matches[1]...</font><br>";
	    break;

	} elseif (preg_match("/:([^!]+)![^\s]+ PRIVMSG ([^\s]+) :(.+)/", $out, $matches)) {
	    if (preg_match("/$nick/i", $matches[3])) { $matches[1] = "<b>$matches[1]</b>"; }
	    $matches[3] = smile_repl(htmlspecialchars($matches[3]));
	    if (preg_match("/$nick/i", $matches[3])) { $matches[1] = "<b>$matches[1]</b>"; /* highlight own nickname */ }
	    if (preg_match("/\001(\w+)(.*)/i", $matches[3], $match)) { // CTCP's
		if ($match[1] == "VERSION") {
		    fputs($socket, "NOTICE $matches[1] :\001VERSION Platonium PHP Chat by Sgorpi v0.5\r\n");
		} elseif ($match[1] == "PING") {
		    fputs($socket, "NOTICE $matches[1] :\001PING$match[2]\r\n");
		} elseif ($match[1] == "CLIENTINFO") {
		    fputs($socket, "NOTICE $matches[1] :\001CLIENTINFO ip: {$HTTP_SERVER_VARS['REMOTE_ADDR']} ; {$HTTP_SERVER_VARS['REMOTE_HOST']}\001\r\n");
		    fputs($socket, "NOTICE $matches[1] :\001CLIENTINFO useragent: {$HTTP_SERVER_VARS['HTTP_USER_AGENT']}\001\r\n");
		} elseif ($match[1] == "ACTION") {
		    $matches[3] = substr($matches[3],7);
		    echo "<font color='$ircColors[6]'>* $matches[1] $matches[3]</font><br>";
		} elseif ($match[1] == "DCC") {
		    preg_match("/^[\W]*(\w+)\s+([^\s]+)\s+\d+\s+\d+[\s\d]*/", "$match[2]", $blaat);
		    echo "<font color='$ircColors[5]'>-- Ignored DCC from $matches[1] ($blaat[1] $blaat[2])</font><br>";
		    fputs($socket, "NOTICE $matches[1] :Sorry, but my client (PHPWebchat) doesn't support DCC transfers.\r\n");
		} else {
		    echo "CTCP: $matches[3]<br>";
		}
	    } elseif (!preg_match("/^#.+/", $matches[2])) {
		echo "&lt;<font color='$ircColors[7]'>$matches[1]-&gt;$nick</font>&gt; $matches[3]<br>";
	    } else {
	        echo "&lt;$matches[1]&gt; $matches[3]<br>";
	    }

	} elseif (preg_match("/:([^!]+)![^\s]+ NICK :(.+)/", $out, $matches)) {
	    if ($nick == $matches[1]) {
		echo "<font color='$ircColors[3]'>-=- You are now known as $matches[2]</font><br>";
	    } else {
		echo "<font color='$ircColors[3]'>-=- $matches[1] is now known as $matches[2]</font><br>";
	    }
	    fputs($socket, "NAMES $matches[2]\r\n");

	} elseif (preg_match("/:([^!]+)![^\s]+ JOIN :(.+)/", $out, $matches)) {
	    echo "<font color='$ircColors[3]'>--&gt; $matches[1] has joined $matches[2]</font><br>";
	    if ($matches[1] != $nick) { fputs($socket, "NAMES $matches[2]\r\n"); }
	    
	} elseif (preg_match("/:([^!]+)![^\s]+ PART (.+)/", $out, $matches)) {
	    if (preg_match("/(#[^\s]+) :(.+)/", $matches[2], $match)) {
		echo "<font color='$ircColors[3]'>&lt;-- $matches[1] has left $match[1] ($match[2])</font><br>";
	    } else {
		echo "<font color='$ircColors[3]'>&lt;-- $matches[1] has left $matches[2]</font><br>";
	    }
	    fputs($socket, "NAMES $matches[2]\r\n");

	} elseif (preg_match("/:([^!]+)![^\s]+ QUIT :(.*)/", $out, $matches)) {
	    echo "<font color='$ircColors[3]'>&lt;-- $matches[1] has quit ($matches[2])</font><br>";
	    fputs($socket, "NAMES #$channel\r\n");
	} elseif (preg_match("/:([^!]+)![^\s]+ TOPIC (#[^\s]+) :(.*)/", $out, $matches)) {
	    echo "<font color='$ircColors[7]'>--- $matches[1] changed the topic for $matches[2] to: $matches[3]</font><br>";

	} elseif (preg_match("/:([^!]+)![^\s]+ MODE (#[^\s]+) ([^\s]+) (.+)/", $out, $matches)) {
	    echo "<font color='$ircColors[7]'>--- $matches[1] sets mode $matches[3] on $matches[4]</font><br>";
	    fputs($socket, "NAMES $matches[2]\r\n");

	} elseif (preg_match("/:([^\s]+) MODE ([^\s]+) :(.+)/", $out, $matches)) {
	    echo "<font color='$ircColors[7]'>--- $matches[1] sets mode $matches[3] on $matches[2]</font><br>";

	} else {
	    echo "$out<br>";

	}
	echo "\n";
    }
    /**********************************************************************************************/
    $result = mysql_query("SELECT commando,tijd FROM phpchat WHERE username = '$user' AND id = $id ORDER BY tijd");
    echo mysql_error();
    $a = 0;
    while ($rij = @mysql_fetch_assoc($result)) {
	$a++;
	mysql_query("DELETE FROM phpchat WHERE username = '$user' AND id = $id AND tijd = {$rij['tijd']} LIMIT 1");
	echo mysql_error();
	if (preg_match("/(PRIVMSG) ([^\s]+) :(.+)/i", $rij['commando'], $match) || preg_match("/(NOTICE) ([^\s]+) :(.+)/i", $rij['commando'], $match)) {
	    $match[3] = smile_repl($match[3]);
	    if ($match[1] == "PRIVMSG") {
		if (preg_match("/\001ACTION ([^\001]+)\001/i", $match[3], $mat)) {
		    echo "<font color='$ircColors[6]'>* $nick $mat[1]</font><br>";
		} elseif (preg_match("/\001(.+)\001/", $match[3], $mat)) { // CTCPs
		    echo "<font color='$ircColors[5]'>CTCP $match[2] $mat[1]</font><br>";
		} elseif (preg_match("/^#.+/", $match[2])) {
		    echo "&lt;$nick&gt; $match[3]<br>";
		} else {
		    echo "&lt;<font color='$ircColors[7]'>$nick-&gt;$match[2]</font>&gt; $match[3]<br>";
		}
	    } elseif ($match[1] == "NOTICE") {
		    echo "<font color='$ircColors[5]'>&gt;$match[2]&lt; $match[3]</font><br>";
	    } else {
		echo "&lt;$nick&gt; $match[2]<br>";
	    }
	}
	if (preg_match("/^NICK (.+)/i", $rij['commando'], $match)) {
	    $nick = $match[1];
	    fputs($socket, "NAMES $channel\r\n");
	    flush();
	}
	fputs($socket, "{$rij['commando']}\r\n");
	if (preg_match("/^QUIT.*/", $rij['commando'])) {
	    echo "<font color='$ircColors[4]'>Disconnected...</font><br>";
	    break 2;
	    break 2;
	}
	echo "\n";
    }
    if ($a > 0) { @set_time_limit(3600); /* ten minutes extra to say sth */ }
    /**********************************************************************************************/
    if ($login == 0) {
	fputs($socket, "USER phpchat {$HTTP_SERVER_VARS['REMOTE_ADDR']} irc.platonium :PHP chatter (c)sgorpi\r\nNICK :".$HTTP_GET_VARS['username']."\r\n");
	$login = 1;
    }
    if (!$inchan && $loggedin) {
	fputs($socket, "JOIN #$channel\r\n");
	$inchan = true;
    }
    if (connection_aborted()) {
	echo "<font color='$ircColors[4]'>Disconnected...</font><br>";
	break 2;
    }
    flush(); //output this...
    usleep(2500); // give cpu some rest... 200 ms?
}
einde();



?>
</body>
</html>
